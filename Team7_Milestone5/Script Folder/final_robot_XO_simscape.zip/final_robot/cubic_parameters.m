
function [C0,C1,C2,C3]=cubic_parameters(q0,qf,qdot0,qdotf,tf)
%1. Demux the joint angles
q1_0=q0(1); q1_f=qf(1);
q2_0=q0(2); q2_f=qf(2);
q3_0=q0(3); q3_f=qf(3);
q4_0=q0(4); q4_f=qf(4);

%2. Demux the joint velocities
q1_dot_0=qdot0(1); q1_dot_f=qdotf(1);
q2_dot_0=qdot0(2); q2_dot_f=qdotf(2);
q3_dot_0=qdot0(3); q3_dot_f=qdotf(3);
q4_dot_0=qdot0(4); q4_dot_f=qdotf(4);

%3. Define vector C0 and C1
C0=[q1_0;q2_0;q3_0;q4_0];
C1=[q1_dot_0;q2_dot_0;q3_dot_0;q4_dot_0];

%4. Define C2,C3 for joint q1
A_q1=[tf^2 , tf^3;
    2*tf , 3*tf^2];
b_q1=[q1_f-q1_0-q1_dot_0*tf; q1_dot_f-q1_dot_0];
ans_q1=linsolve(A_q1,b_q1);
C2_q1=ans_q1(1); C3_q1=ans_q1(2);


%5. Define C2,C3 for joint q2
A_q2=[tf^2 , tf^3;
    2*tf , 3*tf^2];
b_q2=[q2_f-q2_0-q2_dot_0*tf; q2_dot_f-q2_dot_0];
ans_q2=linsolve(A_q2,b_q2);
C2_q2=ans_q2(1); C3_q2=ans_q2(2);

%6. Define C2,C3 for joint q3
A_q3=[tf^2 , tf^3;
    2*tf , 3*tf^2];
b_q3=[q3_f-q3_0-q3_dot_0*tf; q3_dot_f-q3_dot_0];
ans_q3=linsolve(A_q3,b_q3);
C2_q3=ans_q3(1); C3_q3=ans_q3(2);

%7. Define C2,C3 for joint q4
A_q4=[tf^2 , tf^3;
    2*tf , 3*tf^2];
b_q4=[q4_f-q4_0-q4_dot_0*tf; q4_dot_f-q4_dot_0];
ans_q4=linsolve(A_q4,b_q4);
C2_q4=ans_q4(1); C3_q4=ans_q4(2);

%8. Define C2,C3 vectors
C2=[C2_q1;C2_q2;C2_q3;C2_q4];
C3=[C3_q1;C3_q2;C3_q3;C3_q4];

end