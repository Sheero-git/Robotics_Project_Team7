% Input Parameters
A = 0; % Value based on ID (replace with your own)
B = 1; % Value based on ID (replace with your own)
C = 9; % Value based on ID (replace with your own)
D = 4; % Value based on ID (replace with your own)

% Constants
L1 = 1; % Length of the first link (in meters)
L2 = 1; % Length of the second link (in meters)

% Beta calculation based on B
if B > 4
    beta = 0.01;
else
    beta = -0.01;
end

% Time setup
time_steps = 0:0.4*pi:2*pi;

% Preallocating arrays
X = zeros(size(time_steps));
Y = zeros(size(time_steps));
Z = zeros(size(time_steps));
q1 = zeros(size(time_steps));
q2 = zeros(size(time_steps));
q3 = zeros(size(time_steps));

% Loop through each time step to calculate trajectories and joint angles
for i = 1:length(time_steps)
    t = time_steps(i);
    
    % Compute R1 and R2
    R1 = ((5 + C + D) / 10) * (1 + t / (10*pi));
    R2 = ((A + B - 5) / 10) * (1 - t / (10*pi));
    
    % Compute X(t), Y(t), Z(t)
    X(i) = R1 * cos(t);
    Y(i) = R2 * sin(t);
    Z(i) = 1 - beta * t;
    
    % Compute joint angles q1, q2, q3 using inverse kinematics equations
    q1(i) = atan2(Y(i), X(i));
    q2(i) = atan2((Z(i) - L1), sqrt(X(i)^2 + Y(i)^2));
    q3(i) = sqrt((Z(i) - L1)^2 + X(i)^2 + Y(i)^2) - L2;
end

% Display the results in a table format
trajectory_table = table(time_steps', X', Y', Z', q1', q2', q3', ...
    'VariableNames', {'Time', 'X(t)', 'Y(t)', 'Z(t)', 'q1(t)', 'q2(t)', 'q3(t)'});
disp(trajectory_table);

% Optionally, save the results to a file
writetable(trajectory_table, 'robot_trajectory.csv');