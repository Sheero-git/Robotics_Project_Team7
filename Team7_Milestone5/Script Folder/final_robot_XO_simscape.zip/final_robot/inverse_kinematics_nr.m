function q = inverse_kinematics_nr(Xd, Yd, Zd, l1, l2, l3, l4, q_init)
    % Newton-Raphson inverse kinematics solver
    max_iter = 100;
    tol = 1e-6;
    q = q_init;

    for i = 1:max_iter
        % Forward kinematics
        fk = forward_kinematics(q, l1, l2, l3, l4);

        % Compute error
        error = [Xd, Yd, Zd] - fk;

        % Check convergence
        if norm(error) < tol
            return
        end

        % Jacobian matrix
        J = jacobian_matrix(q, l1, l2, l3, l4);

        % Newton-Raphson step
        delta_q = pinv(J) * error';
        q = q + delta_q';
    end
    q=mod(q,2*pi);
    error('Inverse kinematics did not converge');
end

function pos = forward_kinematics(q, l1, l2, l3, l4)
    % Forward kinematics computation
    q1 = q(1);
    q2 = q(2);
    q3 = q(3);
    q4 = q(4);

    X_fk = l2*cos(q1)*cos(q2 + pi/2) - l3*sin(q3)*sin(q2 + pi/2)*cos(q1) ...
           + l3*cos(q1)*cos(q3)*cos(q2 + pi/2) + l4*(-sin(q3)*sin(q2 + pi/2)*cos(q1) ...
           + cos(q1)*cos(q3)*cos(q2 + pi/2))*cos(q4) ...
           + l4*(-sin(q3)*cos(q1)*cos(q2 + pi/2) - sin(q2 + pi/2)*cos(q1)*cos(q3))*sin(q4);
       
    Y_fk = l2*sin(q1)*cos(q2 + pi/2) - l3*sin(q1)*sin(q3)*sin(q2 + pi/2) ...
           + l3*sin(q1)*cos(q3)*cos(q2 + pi/2) + l4*(-sin(q1)*sin(q3)*sin(q2 + pi/2) ...
           + sin(q1)*cos(q3)*cos(q2 + pi/2))*cos(q4) ...
           + l4*(-sin(q1)*sin(q3)*cos(q2 + pi/2) - sin(q1)*sin(q2 + pi/2)*cos(q3))*sin(q4);
       
    Z_fk = l1 + l2*sin(q2 + pi/2) + l3*sin(q3)*cos(q2 + pi/2) + l3*sin(q2 + pi/2)*cos(q3) ...
           + l4*(-sin(q3)*sin(q2 + pi/2) + cos(q3)*cos(q2 + pi/2))*sin(q4) ...
           + l4*(sin(q3)*cos(q2 + pi/2) + sin(q2 + pi/2)*cos(q3))*cos(q4);

    pos = [X_fk, Y_fk, Z_fk];
end

function J = jacobian_matrix(q, l1, l2, l3, l4)
%l1=0.044, l2=0.14, l3=0.134, l4=0.09
    q1_sym=q(1);q2_sym=q(2);q3_sym=q(3); q4_sym=q(4);
    J=[cos(q4_sym)*((9*sin(q1_sym)*sin(q3_sym)*sin(q2_sym + pi/2))/10 - (9*cos(q3_sym)*cos(q2_sym + pi/2)*sin(q1_sym))/10) - (7*cos(q2_sym + pi/2)*sin(q1_sym))/50 + sin(q4_sym)*((9*cos(q3_sym)*sin(q1_sym)*sin(q2_sym + pi/2))/10 + (9*cos(q2_sym + pi/2)*sin(q1_sym)*sin(q3_sym))/10) + (67*sin(q1_sym)*sin(q3_sym)*sin(q2_sym + pi/2))/500 - (67*cos(q3_sym)*cos(q2_sym + pi/2)*sin(q1_sym))/500, sin(q4_sym)*((9*cos(q1_sym)*sin(q3_sym)*sin(q2_sym + pi/2))/10 - (9*cos(q1_sym)*cos(q3_sym)*cos(q2_sym + pi/2))/10) - cos(q4_sym)*((9*cos(q1_sym)*cos(q3_sym)*sin(q2_sym + pi/2))/10 + (9*cos(q1_sym)*cos(q2_sym + pi/2)*sin(q3_sym))/10) - (7*cos(q1_sym)*sin(q2_sym + pi/2))/50 - (67*cos(q1_sym)*cos(q3_sym)*sin(q2_sym + pi/2))/500 - (67*cos(q1_sym)*cos(q2_sym + pi/2)*sin(q3_sym))/500, sin(q4_sym)*((9*cos(q1_sym)*sin(q3_sym)*sin(q2_sym + pi/2))/10 - (9*cos(q1_sym)*cos(q3_sym)*cos(q2_sym + pi/2))/10) - cos(q4_sym)*((9*cos(q1_sym)*cos(q3_sym)*sin(q2_sym + pi/2))/10 + (9*cos(q1_sym)*cos(q2_sym + pi/2)*sin(q3_sym))/10) - (67*cos(q1_sym)*cos(q3_sym)*sin(q2_sym + pi/2))/500 - (67*cos(q1_sym)*cos(q2_sym + pi/2)*sin(q3_sym))/500, sin(q4_sym)*((9*cos(q1_sym)*sin(q3_sym)*sin(q2_sym + pi/2))/10 - (9*cos(q1_sym)*cos(q3_sym)*cos(q2_sym + pi/2))/10) - cos(q4_sym)*((9*cos(q1_sym)*cos(q3_sym)*sin(q2_sym + pi/2))/10 + (9*cos(q1_sym)*cos(q2_sym + pi/2)*sin(q3_sym))/10);
(7*cos(q1_sym)*cos(q2_sym + pi/2))/50 - cos(q4_sym)*((9*cos(q1_sym)*sin(q3_sym)*sin(q2_sym + pi/2))/10 - (9*cos(q1_sym)*cos(q3_sym)*cos(q2_sym + pi/2))/10) - sin(q4_sym)*((9*cos(q1_sym)*cos(q3_sym)*sin(q2_sym + pi/2))/10 + (9*cos(q1_sym)*cos(q2_sym + pi/2)*sin(q3_sym))/10) - (67*cos(q1_sym)*sin(q3_sym)*sin(q2_sym + pi/2))/500 + (67*cos(q1_sym)*cos(q3_sym)*cos(q2_sym + pi/2))/500, sin(q4_sym)*((9*sin(q1_sym)*sin(q3_sym)*sin(q2_sym + pi/2))/10 - (9*cos(q3_sym)*cos(q2_sym + pi/2)*sin(q1_sym))/10) - cos(q4_sym)*((9*cos(q3_sym)*sin(q1_sym)*sin(q2_sym + pi/2))/10 + (9*cos(q2_sym + pi/2)*sin(q1_sym)*sin(q3_sym))/10) - (7*sin(q1_sym)*sin(q2_sym + pi/2))/50 - (67*cos(q3_sym)*sin(q1_sym)*sin(q2_sym + pi/2))/500 - (67*cos(q2_sym + pi/2)*sin(q1_sym)*sin(q3_sym))/500, sin(q4_sym)*((9*sin(q1_sym)*sin(q3_sym)*sin(q2_sym + pi/2))/10 - (9*cos(q3_sym)*cos(q2_sym + pi/2)*sin(q1_sym))/10) - cos(q4_sym)*((9*cos(q3_sym)*sin(q1_sym)*sin(q2_sym + pi/2))/10 + (9*cos(q2_sym + pi/2)*sin(q1_sym)*sin(q3_sym))/10) - (67*cos(q3_sym)*sin(q1_sym)*sin(q2_sym + pi/2))/500 - (67*cos(q2_sym + pi/2)*sin(q1_sym)*sin(q3_sym))/500, sin(q4_sym)*((9*sin(q1_sym)*sin(q3_sym)*sin(q2_sym + pi/2))/10 - (9*cos(q3_sym)*cos(q2_sym + pi/2)*sin(q1_sym))/10) - cos(q4_sym)*((9*cos(q3_sym)*sin(q1_sym)*sin(q2_sym + pi/2))/10 + (9*cos(q2_sym + pi/2)*sin(q1_sym)*sin(q3_sym))/10);
                                                                                                                                                                                                                                                                                                                                                                                            0,                                                                                     (7*cos(q2_sym + pi/2))/50 + (67*cos(q3_sym)*cos(q2_sym + pi/2))/500 - (67*sin(q3_sym)*sin(q2_sym + pi/2))/500 + cos(q4_sym)*((9*cos(q3_sym)*cos(q2_sym + pi/2))/10 - (9*sin(q3_sym)*sin(q2_sym + pi/2))/10) - sin(q4_sym)*((9*cos(q3_sym)*sin(q2_sym + pi/2))/10 + (9*cos(q2_sym + pi/2)*sin(q3_sym))/10),                                                                         (67*cos(q3_sym)*cos(q2_sym + pi/2))/500 - (67*sin(q3_sym)*sin(q2_sym + pi/2))/500 + cos(q4_sym)*((9*cos(q3_sym)*cos(q2_sym + pi/2))/10 - (9*sin(q3_sym)*sin(q2_sym + pi/2))/10) - sin(q4_sym)*((9*cos(q3_sym)*sin(q2_sym + pi/2))/10 + (9*cos(q2_sym + pi/2)*sin(q3_sym))/10),                                                 cos(q4_sym)*((9*cos(q3_sym)*cos(q2_sym + pi/2))/10 - (9*sin(q3_sym)*sin(q2_sym + pi/2))/10) - sin(q4_sym)*((9*cos(q3_sym)*sin(q2_sym + pi/2))/10 + (9*cos(q2_sym + pi/2)*sin(q3_sym))/10)];
end

